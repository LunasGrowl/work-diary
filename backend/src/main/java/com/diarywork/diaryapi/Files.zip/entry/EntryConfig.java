package com.diarywork.diaryapi.entry;

import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.List;

@Configuration
public class EntryConfig {
/*   @Bean
    CommandLineRunner commandLineRunner(EntryRepo entryRepo){
        return args -> {
            Entry day1 = new Entry();
            entryRepo.saveAll(List.of(day1));
        };
    }*/
}
